function tv(str){
    var screenString = screenMessageBox.value;
    screenString = screenString + str;
    screenMessageBox.value = screenString;
    // document.write(str);
} 
function tvscreenPlayerInfo(str){
    var screenString = screenPlayerInfo.value;
    screenPlayerInfo.value = str;
}
function tvscreenGameObject(str){
    var screenString = screenGameObject.value;
    screenGameObject.value = str;
}  
    

function br(){
    document.write("<br>");
}
function hr(){
    document.write("<hr>");
}